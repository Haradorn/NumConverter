package com.example.amadeus.numconverter;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.TextView;

/**
 * Created by AMADEUS on 18.11.2017.
 */

public class HexActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hex);
        String NUMBER = getIntent().getExtras().getString("NUMBER");
        int RESULT;
        TextView HexTextView = (TextView) findViewById(R.id.resultHex);
        if (NUMBER.isEmpty() == true) {
            NUMBER = "Но вы же ничего не ввели!";
            HexTextView.setText(NUMBER);
        } else {
            Double dbRESULT = new Double(Double.parseDouble(NUMBER));
            int intHEXNUM = dbRESULT.intValue();
            int count = (intHEXNUM == 0) ? 1 : 0;
            while (intHEXNUM != 0) {
                count++;
                intHEXNUM /= 10;
            }
            if(count>=10)
            {
                HexTextView.setText("Число слишком длинное");
            }
            else {
                if (dbRESULT % 1 == 0) {
                    RESULT = Integer.parseInt(NUMBER);
                    String INTRESULT = "";
                    while (RESULT >= 16) {
                        switch (RESULT - (RESULT / 16) * 16) {
                            case 10:
                                INTRESULT += "A";
                                break;
                            case 11:
                                INTRESULT += "B";
                                break;
                            case 12:
                                INTRESULT += "C";
                                break;
                            case 13:
                                INTRESULT += "D";
                                break;
                            case 14:
                                INTRESULT += "E";
                                break;
                            case 15:
                                INTRESULT += "F";
                                break;
                            default:
                                INTRESULT += RESULT - (RESULT / 16) * 16;
                                break;
                        }
                        RESULT /= 16;
                    }
                    switch (RESULT) {
                        case 10:
                            INTRESULT += "A";
                            break;
                        case 11:
                            INTRESULT += "B";
                            break;
                        case 12:
                            INTRESULT += "C";
                            break;
                        case 13:
                            INTRESULT += "D";
                            break;
                        case 14:
                            INTRESULT += "E";
                            break;
                        case 15:
                            INTRESULT += "F";
                            break;
                        default:
                            INTRESULT += Integer.toString(RESULT);
                            break;
                    }
                    String ANSWER = new StringBuffer(INTRESULT).reverse().toString();
                    HexTextView.setText("В шестнадцатеричной системе это будет: " + ANSWER);
                } else {
                    RESULT = dbRESULT.intValue();
                    String INTRESULT = "";
                    while (RESULT >= 16) {
                        switch (RESULT - (RESULT / 16) * 16) {
                            case 10:
                                INTRESULT += "A";
                                break;
                            case 11:
                                INTRESULT += "B";
                                break;
                            case 12:
                                INTRESULT += "C";
                                break;
                            case 13:
                                INTRESULT += "D";
                                break;
                            case 14:
                                INTRESULT += "E";
                                break;
                            case 15:
                                INTRESULT += "F";
                                break;
                            default:
                                INTRESULT += RESULT - (RESULT / 16) * 16;
                                break;
                        }
                        RESULT /= 16;
                    }
                    switch (RESULT) {
                        case 10:
                            INTRESULT += "A";
                            break;
                        case 11:
                            INTRESULT += "B";
                            break;
                        case 12:
                            INTRESULT += "C";
                            break;
                        case 13:
                            INTRESULT += "D";
                            break;
                        case 14:
                            INTRESULT += "E";
                            break;
                        case 15:
                            INTRESULT += "F";
                            break;
                        default:
                            INTRESULT += Integer.toString(RESULT);
                            break;
                    }
                    String ANSWER = new StringBuffer(INTRESULT).reverse().toString();

                    int hexRESULT = dbRESULT.intValue();
                    double ostHEX = dbRESULT - hexRESULT;
                    NUMBER = "";

                    for (int i = 1; i < 8; i++) {
                        if ((ostHEX * 16) >= 1) {
                            if ((ostHEX * 16) < 2) {
                                NUMBER += Integer.toString(1);
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 3) {
                                NUMBER += Integer.toString(2);
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 8);
                            } else if ((ostHEX * 16) < 4) {
                                NUMBER += Integer.toString(3);
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 5) {
                                NUMBER += Integer.toString(4);
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 6) {
                                NUMBER += Integer.toString(5);
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 7) {
                                NUMBER += Integer.toString(6);
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 8) {
                                NUMBER += Integer.toString(7);
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 9) {
                                NUMBER += Integer.toString(8);
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 10) {
                                NUMBER += Integer.toString(9);
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 11) {
                                NUMBER += "A";
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 12) {
                                NUMBER += "B";
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 13) {
                                NUMBER += "C";
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 14) {
                                NUMBER += "D";
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 15) {
                                NUMBER += "E";
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            } else if ((ostHEX * 16) < 16) {
                                NUMBER += "F";
                                ostHEX = (ostHEX * 16) - Math.floor(ostHEX * 16);
                            }
                        } else {
                            NUMBER += Integer.toString(0);
                            ostHEX *= 16;
                        }
                    }
                    HexTextView.setText("В шестнадцатеричной системе это будет: " + ANSWER + "." + NUMBER);
                }
            }
        }
    }
}
