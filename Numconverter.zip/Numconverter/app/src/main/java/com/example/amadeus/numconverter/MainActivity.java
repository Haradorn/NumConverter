package com.example.amadeus.numconverter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onRadioClick(View view) {
        EditText numberEditText = (EditText) findViewById(R.id.numEdit);
        switch (view.getId()){
            case R.id.radioBin:
                Intent numIntent = new Intent(MainActivity.this, ResultActivity.class);
                numIntent.putExtra("NUMBER", numberEditText.getText().toString());
                startActivity(numIntent);
                break;
            case R.id.radioHex:
                Intent hexIntent = new Intent(MainActivity.this, HexActivity.class);
                hexIntent.putExtra("NUMBER", numberEditText.getText().toString());
                startActivity(hexIntent);
                break;
            case R.id.radioOct:
                Intent octIntent = new Intent(MainActivity.this, OctActivity.class);
                octIntent.putExtra("NUMBER", numberEditText.getText().toString());
                startActivity(octIntent);
                break;
            default:
                break;
        }
    }
}
