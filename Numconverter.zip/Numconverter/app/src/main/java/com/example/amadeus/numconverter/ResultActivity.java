package com.example.amadeus.numconverter;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

/**
 * Created by AMADEUS on 11.11.2017.
 */

public class ResultActivity extends Activity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        String NUMBER = getIntent().getExtras().getString("NUMBER");
        TextView resultTextView = (TextView)findViewById(R.id.resultView);
        if(NUMBER.isEmpty() == true){
            NUMBER = "Но вы же ничего не ввели!";
            resultTextView.setText(NUMBER);
        }
        else {
            Double RESULT = new Double(Double.parseDouble(NUMBER));
            NUMBER = "";
            int intRESULT = RESULT.intValue();
            int count = (intRESULT == 0) ? 1 : 0;
            while (intRESULT != 0) {
                count++;
                intRESULT /= 10;
            }
            if(count>=10)
            {
                resultTextView.setText("Число слишком длинное");
            }
            else {
                if (RESULT % 1 == 0) {
                    intRESULT = RESULT.intValue();
                    while (intRESULT != 0) {
                        if (intRESULT % 2 == 1) {
                            NUMBER += Integer.toString(1);
                        } else NUMBER += Integer.toString(0);
                        intRESULT = intRESULT / 2;
                    }
                    String ANSWER = new StringBuffer(NUMBER).reverse().toString();
                    resultTextView.setText("В двоичной системе это будет: " + ANSWER);
                } else {
                    intRESULT = RESULT.intValue();
                    while (intRESULT != 0) {
                        if (intRESULT % 2 == 1) {
                            NUMBER += Integer.toString(1);
                        } else NUMBER += Integer.toString(0);
                        intRESULT = intRESULT / 2;
                    }
                    String IntANSWER = new StringBuffer(NUMBER).reverse().toString();
                    NUMBER = "";
                    intRESULT = RESULT.intValue();
                    double dbRESULT = RESULT - intRESULT;
                    for (int i = 1; i < 8; i++) {
                        if (dbRESULT * 2 >= 1) {
                            NUMBER += Integer.toString(1);
                            double dbRESULT2 = (dbRESULT * 2) - 1;
                            dbRESULT = dbRESULT2;
                        } else {
                            NUMBER += Integer.toString(0);
                            dbRESULT *= 2;
                        }
                    }
                    resultTextView.setText("В двоичной системе это будет: " + String.valueOf(IntANSWER) + "." + String.valueOf(NUMBER));
                }
            }
        }
    }
}
