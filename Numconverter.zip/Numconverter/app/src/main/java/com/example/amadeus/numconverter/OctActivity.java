package com.example.amadeus.numconverter;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

/**
 * Created by AMADEUS on 18.11.2017.
 */

public class OctActivity extends Activity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oct);
        String NUMBER = getIntent().getExtras().getString("NUMBER");
        TextView OctTextView = (TextView)findViewById(R.id.resultOct);
        if(NUMBER.isEmpty() == true)
        {
            NUMBER = "Но вы же ничего не ввели!";
            OctTextView.setText(NUMBER);
        }
        else
        {
            Double OCTNUM = new Double(Double.parseDouble(NUMBER));
            NUMBER = "";
            int intOCTNUM = OCTNUM.intValue();
            int count = (intOCTNUM == 0) ? 1 : 0;
            while (intOCTNUM != 0) {
                count++;
                intOCTNUM /= 10;
            }
            if(count>=10)
            {
                OctTextView.setText("Число слишком длинное");
            }
            else {
                if (OCTNUM % 1 == 0) {
                    intOCTNUM = OCTNUM.intValue();
                    while (intOCTNUM >= 8) {
                        NUMBER += Integer.toString(intOCTNUM - ((intOCTNUM / 8) * 8));
                        intOCTNUM = intOCTNUM / 8;
                    }
                    NUMBER += Integer.toString(intOCTNUM);
                    String ANSWER = new StringBuffer(NUMBER).reverse().toString();
                    OctTextView.setText("В восьмеричной системе это будет: " + ANSWER);
                } else {
                    intOCTNUM = OCTNUM.intValue();
                    while (intOCTNUM >= 8) {
                        NUMBER += Integer.toString(intOCTNUM - ((intOCTNUM / 8) * 8));
                        intOCTNUM = intOCTNUM / 8;
                    }
                    NUMBER += Integer.toString(intOCTNUM);
                    String intANSWER = new StringBuffer(NUMBER).reverse().toString();
                    NUMBER = "";
                    intOCTNUM = OCTNUM.intValue();
                    double OCTOST = OCTNUM - intOCTNUM;//выводит остаток
                    for (int i = 1; i < 8; i++) {
                        if ((OCTOST * 8) >= 1) {
                            if ((OCTOST * 8) < 2) {
                                NUMBER += Integer.toString(1);
                                OCTOST = (OCTOST * 8) - Math.floor(OCTOST * 8);
                            } else if ((OCTOST * 8) < 3) {
                                NUMBER += Integer.toString(2);
                                OCTOST = (OCTOST * 8) - Math.floor(OCTOST * 8);
                            } else if ((OCTOST * 8) < 4) {
                                NUMBER += Integer.toString(3);
                                OCTOST = (OCTOST * 8) - Math.floor(OCTOST * 8);
                            } else if ((OCTOST * 8) < 5) {
                                NUMBER += Integer.toString(4);
                                OCTOST = (OCTOST * 8) - Math.floor(OCTOST * 8);
                            } else if ((OCTOST * 8) < 6) {
                                NUMBER += Integer.toString(5);
                                OCTOST = (OCTOST * 8) - Math.floor(OCTOST * 8);
                            } else if ((OCTOST * 8) < 7) {
                                NUMBER += Integer.toString(6);
                                OCTOST = (OCTOST * 8) - Math.floor(OCTOST * 8);
                            } else if ((OCTOST * 8) < 8) {
                                NUMBER += Integer.toString(7);
                                OCTOST = (OCTOST * 8) - Math.floor(OCTOST * 8);
                            } else if ((OCTOST * 8) < 9) {
                                NUMBER += Integer.toString(8);
                                OCTOST = (OCTOST * 8) - Math.floor(OCTOST * 8);
                            } else if ((OCTOST * 8) < 10) {
                                NUMBER += Integer.toString(9);
                                OCTOST = (OCTOST * 8) - Math.floor(OCTOST * 8);
                            }
                        } else {
                            NUMBER += Integer.toString(0);
                            OCTOST *= 8;
                        }
                    }
                    OctTextView.setText("В восьмеричной системе это будет: " + String.valueOf(intANSWER) + "." + String.valueOf(NUMBER));
                }
            }
        }
    }
}
